# Calculator
Hi there,
Simple calculator made with HTML, CSS, and JavaScript. It can perform basic arithmetic operations like addition, subtraction, multiplication, and division. Check out the code on my GitHub.
